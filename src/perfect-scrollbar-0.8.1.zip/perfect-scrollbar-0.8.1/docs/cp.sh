#!/usr/bin/env bash
cp ../dist/js/perfect-scrollbar.min.js ./
cp ../dist/css/perfect-scrollbar.min.css ./
